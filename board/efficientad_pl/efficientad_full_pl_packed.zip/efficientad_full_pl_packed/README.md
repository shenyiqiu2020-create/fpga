# EfficientAD DSP 打包计算核

独立于 `../efficientad_full_pl_opt`（已板测约9.44秒/图）。原工作工程与模型文件保留。
最新结果见 `RESULTS.md`，证据与文件哈希见 `generated/kernel_optimization.json`。
2026-11-01最终版已通过实际板测：两张图的58个阶段CRC与最终分数全部一致。
FPGA计算约4.507秒/图，含原有自检总耗时约5.041秒/图；上一版分别约8.914秒和9.443秒。
最终50 MHz时序WNS=+1.862ns、WHS=+0.039ns，208 DSP、22429 LUT、49 BRAM36。

## 核内改动

- 输出并行通道由16增至32，SIMD保持8，乘加阵列每拍处理256个INT8乘加。
- 两个输出通道共享同一输入，把两个有符号INT8权重打包为一个25位操作数。
  复用未修改的 FINN `mul(..., ap_resource_dsp())`，一次DSP乘法恢复两个独立乘积。
  低16位为负时修正高半部分的借位，避免负数串扰；没有改变量化位宽或权重。
- INT8重定标由1路改为4路，减少像素之间的等待。乘加循环保持II=1。
- 保留64 KiB行缓存、相同的50 MHz时钟、Q30重定标、ReLU、平均池化和网络内部Resize。
- 32通道一组使行缓存对整张输入的重复加载次数减半。输出仍写入DDR，运行时仍是一个通用核逐层执行。
- 兼容16输出通道的部分块，但冻结模型的所有卷积输出通道数均为32的倍数。

DSP48E1结构依据：
[AMD 7 Series DSP48E1 User Guide, UG479](https://docs.amd.com/api/khub/documents/gu4oRPFEh_Pm2uaAlfY6Kg/content)。
该器件支持25×18位有符号乘法。具体打包、拆分、控制和累加是本工程适配代码。
FINN源码及BSD-3-Clause许可保留在 `hls/vendor/finn-hlslib`。

## 验证

- NumPy穷举全部16,777,216种有符号INT8输入/权重三元组，证明两个乘积均精确恢复。
- 原PE32、单路重定标中间版本通过24组C/RTL对照，记录在 `experiments/packed_scalar`。
- 最终PE32/Q4：27组C仿真；20组卷积RTL对照，包含大通道、多个输出通道块、边界和符号情况。
- Resize逻辑未修改，中间版本原7组Resize RTL已通过；最终完整模型上板时仍逐层检查其CRC。
- 三组代表性输入与旧PE16核使用完全相同的数据比较RTL周期，位于 `compare_hls` 与最终报告。
- 上板时检查两张图片共58个阶段CRC和最终分数。最终状态请以结果报告为准。
- 两张调试图片用于定标和自检，依然不构成独立INT8精度评估。

## 运行

1. 接原电源和已验证的JTAG电缆，串口助手COM11、115200 8N1。
2. 运行 `RUN_PACKED.cmd`，临时下载本目录的bit与ELF，不写Flash。
3. 等两张图完成，运行 `READ_PROFILE.cmd` 读取DDR分项计时与校验结果。
4. UART应显示 `Kernel: DSP-packed PE32 SIMD8, 4 requant lanes`。

两张图分数仍应约为D19_01=0.345157206（DEFECT）、N17_03=0.073264331（NORMAL）。
完整统计见 `generated/efficientad_full_board_profile.json`。
需要回退时运行旧目录 `../efficientad_full_pl_opt/RUN_OPTIMIZED.cmd`。

Vivado：打开本目录 `_build/vivado/ea_full.xpr`，再打开 `design_full`。
Vitis：用本目录 `generated/ax7021_efficientad_full.xsa` 创建平台，standalone、ps7_cortexa9_0；
应用源文件在 `app_sources`，编译级别为-O2。不要将旧硬件与新应用混用。
压缩包不包含庞大的临时工程数据库；单独解压后先运行构建脚本生成xpr。

## 重建

- `scripts/build_hls.tcl`：EA_STAGE=prepare，EA_FIXTURE指向generated/packed_tests.bin，执行27组C仿真、综合和IP打包。
- EA_STAGE=verify_compute：最终20组卷积C/RTL对照；EA_STAGE=all可执行所选输入文件的全部C/RTL和打包流程。
- `scripts/build_vivado.tcl`：生成本目录硬件和含bitstream的XSA。
- `scripts/build_app.py`：使用原平台已验证且PS配置相同的BSP编译独立应用，只读取旧平台文件。
- `scripts/summarize_kernel.py`：汇总测试、布局布线、板测、逐层速度与哈希。
- `scripts/check_rtl.py --vivado`：核对综合、通过仿真的参考RTL、导出IP和Vivado实际导入文件。
  构建脚本在每次综合前归档旧HLS solution并从新solution重建，防止HLS导出缓存保留旧RTL。

所有统计均保留相同的查表CRC自检。
