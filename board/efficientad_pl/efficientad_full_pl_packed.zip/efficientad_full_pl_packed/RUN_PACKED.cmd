@echo off
echo Loading DSP-packed PE32/Q4 kernel temporarily through JTAG. No Flash programming.
call D:\amd\2025.2\Vitis\bin\xsdb.bat "%~dp0scripts\deploy_jtag.tcl"
echo Watch COM11 at 115200 8N1. After both images finish run READ_PROFILE.cmd.
pause
