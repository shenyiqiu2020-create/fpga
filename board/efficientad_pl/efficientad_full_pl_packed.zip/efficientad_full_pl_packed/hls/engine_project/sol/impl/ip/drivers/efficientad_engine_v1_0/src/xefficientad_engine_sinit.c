// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xefficientad_engine.h"

extern XEfficientad_engine_Config XEfficientad_engine_ConfigTable[];

#ifdef SDT
XEfficientad_engine_Config *XEfficientad_engine_LookupConfig(UINTPTR BaseAddress) {
	XEfficientad_engine_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XEfficientad_engine_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XEfficientad_engine_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XEfficientad_engine_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XEfficientad_engine_Initialize(XEfficientad_engine *InstancePtr, UINTPTR BaseAddress) {
	XEfficientad_engine_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XEfficientad_engine_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XEfficientad_engine_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XEfficientad_engine_Config *XEfficientad_engine_LookupConfig(u16 DeviceId) {
	XEfficientad_engine_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XEFFICIENTAD_ENGINE_NUM_INSTANCES; Index++) {
		if (XEfficientad_engine_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XEfficientad_engine_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XEfficientad_engine_Initialize(XEfficientad_engine *InstancePtr, u16 DeviceId) {
	XEfficientad_engine_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XEfficientad_engine_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XEfficientad_engine_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

