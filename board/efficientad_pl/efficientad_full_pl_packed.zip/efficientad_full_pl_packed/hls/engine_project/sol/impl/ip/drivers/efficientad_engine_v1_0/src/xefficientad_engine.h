// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XEFFICIENTAD_ENGINE_H
#define XEFFICIENTAD_ENGINE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xefficientad_engine_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XEfficientad_engine_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XEfficientad_engine;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XEfficientad_engine_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XEfficientad_engine_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XEfficientad_engine_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XEfficientad_engine_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XEfficientad_engine_Initialize(XEfficientad_engine *InstancePtr, UINTPTR BaseAddress);
XEfficientad_engine_Config* XEfficientad_engine_LookupConfig(UINTPTR BaseAddress);
#else
int XEfficientad_engine_Initialize(XEfficientad_engine *InstancePtr, u16 DeviceId);
XEfficientad_engine_Config* XEfficientad_engine_LookupConfig(u16 DeviceId);
#endif
int XEfficientad_engine_CfgInitialize(XEfficientad_engine *InstancePtr, XEfficientad_engine_Config *ConfigPtr);
#else
int XEfficientad_engine_Initialize(XEfficientad_engine *InstancePtr, const char* InstanceName);
int XEfficientad_engine_Release(XEfficientad_engine *InstancePtr);
#endif

void XEfficientad_engine_Start(XEfficientad_engine *InstancePtr);
u32 XEfficientad_engine_IsDone(XEfficientad_engine *InstancePtr);
u32 XEfficientad_engine_IsIdle(XEfficientad_engine *InstancePtr);
u32 XEfficientad_engine_IsReady(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_EnableAutoRestart(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_DisableAutoRestart(XEfficientad_engine *InstancePtr);
u32 XEfficientad_engine_Get_return(XEfficientad_engine *InstancePtr);

void XEfficientad_engine_Set_mem(XEfficientad_engine *InstancePtr, u64 Data);
u64 XEfficientad_engine_Get_mem(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_opcode(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_opcode(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_src(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_src(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_dst(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_dst(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_weights(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_weights(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_biases(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_biases(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_multipliers(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_multipliers(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_ih(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_ih(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_iw(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_iw(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_cin(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_cin(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_cout(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_cout(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_kernel(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_kernel(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_stride(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_stride(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_pad(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_pad(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_relu(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_relu(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_pool(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_pool(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_oh(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_oh(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_ow(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_ow(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_Set_coordinates(XEfficientad_engine *InstancePtr, u32 Data);
u32 XEfficientad_engine_Get_coordinates(XEfficientad_engine *InstancePtr);

void XEfficientad_engine_InterruptGlobalEnable(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_InterruptGlobalDisable(XEfficientad_engine *InstancePtr);
void XEfficientad_engine_InterruptEnable(XEfficientad_engine *InstancePtr, u32 Mask);
void XEfficientad_engine_InterruptDisable(XEfficientad_engine *InstancePtr, u32 Mask);
void XEfficientad_engine_InterruptClear(XEfficientad_engine *InstancePtr, u32 Mask);
u32 XEfficientad_engine_InterruptGetEnabled(XEfficientad_engine *InstancePtr);
u32 XEfficientad_engine_InterruptGetStatus(XEfficientad_engine *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
