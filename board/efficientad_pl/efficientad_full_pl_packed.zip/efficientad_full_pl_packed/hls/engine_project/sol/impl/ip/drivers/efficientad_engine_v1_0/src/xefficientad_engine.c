// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xefficientad_engine.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XEfficientad_engine_CfgInitialize(XEfficientad_engine *InstancePtr, XEfficientad_engine_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XEfficientad_engine_Start(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XEfficientad_engine_IsDone(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XEfficientad_engine_IsIdle(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XEfficientad_engine_IsReady(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XEfficientad_engine_EnableAutoRestart(XEfficientad_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XEfficientad_engine_DisableAutoRestart(XEfficientad_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XEfficientad_engine_Get_return(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XEfficientad_engine_Set_mem(XEfficientad_engine *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_MEM_DATA, (u32)(Data));
    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_MEM_DATA + 4, (u32)(Data >> 32));
}

u64 XEfficientad_engine_Get_mem(XEfficientad_engine *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_MEM_DATA);
    Data += (u64)XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_MEM_DATA + 4) << 32;
    return Data;
}

void XEfficientad_engine_Set_opcode(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_OPCODE_DATA, Data);
}

u32 XEfficientad_engine_Get_opcode(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_OPCODE_DATA);
    return Data;
}

void XEfficientad_engine_Set_src(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_SRC_DATA, Data);
}

u32 XEfficientad_engine_Get_src(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_SRC_DATA);
    return Data;
}

void XEfficientad_engine_Set_dst(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_DST_DATA, Data);
}

u32 XEfficientad_engine_Get_dst(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_DST_DATA);
    return Data;
}

void XEfficientad_engine_Set_weights(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_WEIGHTS_DATA, Data);
}

u32 XEfficientad_engine_Get_weights(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_WEIGHTS_DATA);
    return Data;
}

void XEfficientad_engine_Set_biases(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_BIASES_DATA, Data);
}

u32 XEfficientad_engine_Get_biases(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_BIASES_DATA);
    return Data;
}

void XEfficientad_engine_Set_multipliers(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_MULTIPLIERS_DATA, Data);
}

u32 XEfficientad_engine_Get_multipliers(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_MULTIPLIERS_DATA);
    return Data;
}

void XEfficientad_engine_Set_ih(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_IH_DATA, Data);
}

u32 XEfficientad_engine_Get_ih(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_IH_DATA);
    return Data;
}

void XEfficientad_engine_Set_iw(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_IW_DATA, Data);
}

u32 XEfficientad_engine_Get_iw(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_IW_DATA);
    return Data;
}

void XEfficientad_engine_Set_cin(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_CIN_DATA, Data);
}

u32 XEfficientad_engine_Get_cin(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_CIN_DATA);
    return Data;
}

void XEfficientad_engine_Set_cout(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_COUT_DATA, Data);
}

u32 XEfficientad_engine_Get_cout(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_COUT_DATA);
    return Data;
}

void XEfficientad_engine_Set_kernel(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_KERNEL_DATA, Data);
}

u32 XEfficientad_engine_Get_kernel(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_KERNEL_DATA);
    return Data;
}

void XEfficientad_engine_Set_stride(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_STRIDE_DATA, Data);
}

u32 XEfficientad_engine_Get_stride(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_STRIDE_DATA);
    return Data;
}

void XEfficientad_engine_Set_pad(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_PAD_DATA, Data);
}

u32 XEfficientad_engine_Get_pad(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_PAD_DATA);
    return Data;
}

void XEfficientad_engine_Set_relu(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_RELU_DATA, Data);
}

u32 XEfficientad_engine_Get_relu(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_RELU_DATA);
    return Data;
}

void XEfficientad_engine_Set_pool(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_POOL_DATA, Data);
}

u32 XEfficientad_engine_Get_pool(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_POOL_DATA);
    return Data;
}

void XEfficientad_engine_Set_oh(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_OH_DATA, Data);
}

u32 XEfficientad_engine_Get_oh(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_OH_DATA);
    return Data;
}

void XEfficientad_engine_Set_ow(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_OW_DATA, Data);
}

u32 XEfficientad_engine_Get_ow(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_OW_DATA);
    return Data;
}

void XEfficientad_engine_Set_coordinates(XEfficientad_engine *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_COORDINATES_DATA, Data);
}

u32 XEfficientad_engine_Get_coordinates(XEfficientad_engine *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_COORDINATES_DATA);
    return Data;
}

void XEfficientad_engine_InterruptGlobalEnable(XEfficientad_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_GIE, 1);
}

void XEfficientad_engine_InterruptGlobalDisable(XEfficientad_engine *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_GIE, 0);
}

void XEfficientad_engine_InterruptEnable(XEfficientad_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_IER);
    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_IER, Register | Mask);
}

void XEfficientad_engine_InterruptDisable(XEfficientad_engine *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_IER);
    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XEfficientad_engine_InterruptClear(XEfficientad_engine *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEfficientad_engine_WriteReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_ISR, Mask);
}

u32 XEfficientad_engine_InterruptGetEnabled(XEfficientad_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_IER);
}

u32 XEfficientad_engine_InterruptGetStatus(XEfficientad_engine *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEfficientad_engine_ReadReg(InstancePtr->Control_BaseAddress, XEFFICIENTAD_ENGINE_CONTROL_ADDR_ISR);
}

