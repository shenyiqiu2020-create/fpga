-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
-- Tool Version Limit: 2025.11
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- 
-- ==============================================================
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity efficientad_engine_control_s_axi is
generic (
    C_S_AXI_ADDR_WIDTH    : INTEGER := 8;
    C_S_AXI_DATA_WIDTH    : INTEGER := 32);
port (
    ACLK                  :in   STD_LOGIC;
    ARESET                :in   STD_LOGIC;
    ACLK_EN               :in   STD_LOGIC;
    AWADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    AWVALID               :in   STD_LOGIC;
    AWREADY               :out  STD_LOGIC;
    WDATA                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    WSTRB                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH/8-1 downto 0);
    WVALID                :in   STD_LOGIC;
    WREADY                :out  STD_LOGIC;
    BRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    BVALID                :out  STD_LOGIC;
    BREADY                :in   STD_LOGIC;
    ARADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    ARVALID               :in   STD_LOGIC;
    ARREADY               :out  STD_LOGIC;
    RDATA                 :out  STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    RRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    RVALID                :out  STD_LOGIC;
    RREADY                :in   STD_LOGIC;
    interrupt             :out  STD_LOGIC;
    ap_start              :out  STD_LOGIC;
    ap_done               :in   STD_LOGIC;
    ap_ready              :in   STD_LOGIC;
    ap_idle               :in   STD_LOGIC;
    ap_return             :in   STD_LOGIC_VECTOR(31 downto 0);
    mem                   :out  STD_LOGIC_VECTOR(63 downto 0);
    opcode                :out  STD_LOGIC_VECTOR(31 downto 0);
    src                   :out  STD_LOGIC_VECTOR(31 downto 0);
    dst                   :out  STD_LOGIC_VECTOR(31 downto 0);
    weights               :out  STD_LOGIC_VECTOR(31 downto 0);
    biases                :out  STD_LOGIC_VECTOR(31 downto 0);
    multipliers           :out  STD_LOGIC_VECTOR(31 downto 0);
    ih                    :out  STD_LOGIC_VECTOR(31 downto 0);
    iw                    :out  STD_LOGIC_VECTOR(31 downto 0);
    cin                   :out  STD_LOGIC_VECTOR(31 downto 0);
    cout                  :out  STD_LOGIC_VECTOR(31 downto 0);
    kernel                :out  STD_LOGIC_VECTOR(31 downto 0);
    stride                :out  STD_LOGIC_VECTOR(31 downto 0);
    pad                   :out  STD_LOGIC_VECTOR(31 downto 0);
    relu                  :out  STD_LOGIC_VECTOR(31 downto 0);
    pool                  :out  STD_LOGIC_VECTOR(31 downto 0);
    oh                    :out  STD_LOGIC_VECTOR(31 downto 0);
    ow                    :out  STD_LOGIC_VECTOR(31 downto 0);
    coordinates           :out  STD_LOGIC_VECTOR(31 downto 0)
);
end entity efficientad_engine_control_s_axi;

-- ------------------------Address Info-------------------
-- Protocol Used: ap_ctrl_hs
--
-- 0x00 : Control signals
--        bit 0  - ap_start (Read/Write/COH)
--        bit 1  - ap_done (Read/COR)
--        bit 2  - ap_idle (Read)
--        bit 3  - ap_ready (Read/COR)
--        bit 7  - auto_restart (Read/Write)
--        bit 9  - interrupt (Read)
--        others - reserved
-- 0x04 : Global Interrupt Enable Register
--        bit 0  - Global Interrupt Enable (Read/Write)
--        others - reserved
-- 0x08 : IP Interrupt Enable Register (Read/Write)
--        bit 0 - enable ap_done interrupt (Read/Write)
--        bit 1 - enable ap_ready interrupt (Read/Write)
--        others - reserved
-- 0x0c : IP Interrupt Status Register (Read/TOW)
--        bit 0 - ap_done (Read/TOW)
--        bit 1 - ap_ready (Read/TOW)
--        others - reserved
-- 0x10 : Data signal of ap_return
--        bit 31~0 - ap_return[31:0] (Read)
-- 0x18 : Data signal of mem
--        bit 31~0 - mem[31:0] (Read/Write)
-- 0x1c : Data signal of mem
--        bit 31~0 - mem[63:32] (Read/Write)
-- 0x20 : reserved
-- 0x28 : Data signal of opcode
--        bit 31~0 - opcode[31:0] (Read/Write)
-- 0x2c : reserved
-- 0x30 : Data signal of src
--        bit 31~0 - src[31:0] (Read/Write)
-- 0x34 : reserved
-- 0x38 : Data signal of dst
--        bit 31~0 - dst[31:0] (Read/Write)
-- 0x3c : reserved
-- 0x40 : Data signal of weights
--        bit 31~0 - weights[31:0] (Read/Write)
-- 0x44 : reserved
-- 0x48 : Data signal of biases
--        bit 31~0 - biases[31:0] (Read/Write)
-- 0x4c : reserved
-- 0x50 : Data signal of multipliers
--        bit 31~0 - multipliers[31:0] (Read/Write)
-- 0x54 : reserved
-- 0x58 : Data signal of ih
--        bit 31~0 - ih[31:0] (Read/Write)
-- 0x5c : reserved
-- 0x60 : Data signal of iw
--        bit 31~0 - iw[31:0] (Read/Write)
-- 0x64 : reserved
-- 0x68 : Data signal of cin
--        bit 31~0 - cin[31:0] (Read/Write)
-- 0x6c : reserved
-- 0x70 : Data signal of cout
--        bit 31~0 - cout[31:0] (Read/Write)
-- 0x74 : reserved
-- 0x78 : Data signal of kernel
--        bit 31~0 - kernel[31:0] (Read/Write)
-- 0x7c : reserved
-- 0x80 : Data signal of stride
--        bit 31~0 - stride[31:0] (Read/Write)
-- 0x84 : reserved
-- 0x88 : Data signal of pad
--        bit 31~0 - pad[31:0] (Read/Write)
-- 0x8c : reserved
-- 0x90 : Data signal of relu
--        bit 31~0 - relu[31:0] (Read/Write)
-- 0x94 : reserved
-- 0x98 : Data signal of pool
--        bit 31~0 - pool[31:0] (Read/Write)
-- 0x9c : reserved
-- 0xa0 : Data signal of oh
--        bit 31~0 - oh[31:0] (Read/Write)
-- 0xa4 : reserved
-- 0xa8 : Data signal of ow
--        bit 31~0 - ow[31:0] (Read/Write)
-- 0xac : reserved
-- 0xb0 : Data signal of coordinates
--        bit 31~0 - coordinates[31:0] (Read/Write)
-- 0xb4 : reserved
-- (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

architecture behave of efficientad_engine_control_s_axi is
attribute DowngradeIPIdentifiedWarnings : STRING;
attribute DowngradeIPIdentifiedWarnings of behave : architecture is "yes";
    type states is (wridle, wrdata, wrresp, wrreset, rdidle, rddata, rdreset);  -- read and write fsm states
    signal wstate  : states := wrreset;
    signal rstate  : states := rdreset;
    signal wnext, rnext: states;
    constant ADDR_AP_CTRL            : INTEGER := 16#00#;
    constant ADDR_GIE                : INTEGER := 16#04#;
    constant ADDR_IER                : INTEGER := 16#08#;
    constant ADDR_ISR                : INTEGER := 16#0c#;
    constant ADDR_AP_RETURN_0        : INTEGER := 16#10#;
    constant ADDR_MEM_DATA_0         : INTEGER := 16#18#;
    constant ADDR_MEM_DATA_1         : INTEGER := 16#1c#;
    constant ADDR_MEM_CTRL           : INTEGER := 16#20#;
    constant ADDR_OPCODE_DATA_0      : INTEGER := 16#28#;
    constant ADDR_OPCODE_CTRL        : INTEGER := 16#2c#;
    constant ADDR_SRC_DATA_0         : INTEGER := 16#30#;
    constant ADDR_SRC_CTRL           : INTEGER := 16#34#;
    constant ADDR_DST_DATA_0         : INTEGER := 16#38#;
    constant ADDR_DST_CTRL           : INTEGER := 16#3c#;
    constant ADDR_WEIGHTS_DATA_0     : INTEGER := 16#40#;
    constant ADDR_WEIGHTS_CTRL       : INTEGER := 16#44#;
    constant ADDR_BIASES_DATA_0      : INTEGER := 16#48#;
    constant ADDR_BIASES_CTRL        : INTEGER := 16#4c#;
    constant ADDR_MULTIPLIERS_DATA_0 : INTEGER := 16#50#;
    constant ADDR_MULTIPLIERS_CTRL   : INTEGER := 16#54#;
    constant ADDR_IH_DATA_0          : INTEGER := 16#58#;
    constant ADDR_IH_CTRL            : INTEGER := 16#5c#;
    constant ADDR_IW_DATA_0          : INTEGER := 16#60#;
    constant ADDR_IW_CTRL            : INTEGER := 16#64#;
    constant ADDR_CIN_DATA_0         : INTEGER := 16#68#;
    constant ADDR_CIN_CTRL           : INTEGER := 16#6c#;
    constant ADDR_COUT_DATA_0        : INTEGER := 16#70#;
    constant ADDR_COUT_CTRL          : INTEGER := 16#74#;
    constant ADDR_KERNEL_DATA_0      : INTEGER := 16#78#;
    constant ADDR_KERNEL_CTRL        : INTEGER := 16#7c#;
    constant ADDR_STRIDE_DATA_0      : INTEGER := 16#80#;
    constant ADDR_STRIDE_CTRL        : INTEGER := 16#84#;
    constant ADDR_PAD_DATA_0         : INTEGER := 16#88#;
    constant ADDR_PAD_CTRL           : INTEGER := 16#8c#;
    constant ADDR_RELU_DATA_0        : INTEGER := 16#90#;
    constant ADDR_RELU_CTRL          : INTEGER := 16#94#;
    constant ADDR_POOL_DATA_0        : INTEGER := 16#98#;
    constant ADDR_POOL_CTRL          : INTEGER := 16#9c#;
    constant ADDR_OH_DATA_0          : INTEGER := 16#a0#;
    constant ADDR_OH_CTRL            : INTEGER := 16#a4#;
    constant ADDR_OW_DATA_0          : INTEGER := 16#a8#;
    constant ADDR_OW_CTRL            : INTEGER := 16#ac#;
    constant ADDR_COORDINATES_DATA_0 : INTEGER := 16#b0#;
    constant ADDR_COORDINATES_CTRL   : INTEGER := 16#b4#;
    constant ADDR_BITS         : INTEGER := 8;

    signal AWREADY_t           : STD_LOGIC;
    signal WREADY_t            : STD_LOGIC;
    signal ARREADY_t           : STD_LOGIC;
    signal RVALID_t            : STD_LOGIC;
    signal BVALID_t            : STD_LOGIC;
    signal waddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal wmask               : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal aw_hs               : STD_LOGIC;
    signal w_hs                : STD_LOGIC;
    signal rdata_data          : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal ar_hs               : STD_LOGIC;
    signal raddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    -- internal registers
    signal int_ap_idle         : STD_LOGIC := '0';
    signal int_ap_ready        : STD_LOGIC := '0';
    signal task_ap_ready       : STD_LOGIC;
    signal int_ap_done         : STD_LOGIC := '0';
    signal task_ap_done        : STD_LOGIC;
    signal int_task_ap_done    : STD_LOGIC := '0';
    signal int_ap_start        : STD_LOGIC := '0';
    signal int_interrupt       : STD_LOGIC := '0';
    signal int_auto_restart    : STD_LOGIC := '0';
    signal auto_restart_status : STD_LOGIC := '0';
    signal auto_restart_done   : STD_LOGIC;
    signal int_gie             : STD_LOGIC := '0';
    signal int_ier             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_isr             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_ap_return       : UNSIGNED(31 downto 0);
    signal int_mem             : UNSIGNED(63 downto 0) := (others => '0');
    signal int_opcode          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_src             : UNSIGNED(31 downto 0) := (others => '0');
    signal int_dst             : UNSIGNED(31 downto 0) := (others => '0');
    signal int_weights         : UNSIGNED(31 downto 0) := (others => '0');
    signal int_biases          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_multipliers     : UNSIGNED(31 downto 0) := (others => '0');
    signal int_ih              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_iw              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_cin             : UNSIGNED(31 downto 0) := (others => '0');
    signal int_cout            : UNSIGNED(31 downto 0) := (others => '0');
    signal int_kernel          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_stride          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_pad             : UNSIGNED(31 downto 0) := (others => '0');
    signal int_relu            : UNSIGNED(31 downto 0) := (others => '0');
    signal int_pool            : UNSIGNED(31 downto 0) := (others => '0');
    signal int_oh              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_ow              : UNSIGNED(31 downto 0) := (others => '0');
    signal int_coordinates     : UNSIGNED(31 downto 0) := (others => '0');


begin
-- ----------------------- Instantiation------------------


-- ----------------------- AXI WRITE ---------------------
    AWREADY_t <=  '1' when wstate = wridle else '0';
    AWREADY   <=  AWREADY_t;
    WREADY_t  <=  '1' when wstate = wrdata else '0';
    WREADY    <=  WREADY_t;
    BVALID_t  <=  '1' when wstate = wrresp else '0';
    BVALID    <=  BVALID_t;
    BRESP     <=  "00";  -- OKAY
    wmask     <=  (31 downto 24 => WSTRB(3), 23 downto 16 => WSTRB(2), 15 downto 8 => WSTRB(1), 7 downto 0 => WSTRB(0));
    aw_hs     <=  AWVALID and AWREADY_t;
    w_hs      <=  WVALID and WREADY_t;

    -- write FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                wstate <= wrreset;
            elsif (ACLK_EN = '1') then
                wstate <= wnext;
            end if;
        end if;
    end process;

    process (wstate, AWVALID, WVALID, BREADY, BVALID_t)
    begin
        case (wstate) is
        when wridle =>
            if (AWVALID = '1') then
                wnext <= wrdata;
            else
                wnext <= wridle;
            end if;
        when wrdata =>
            if (WVALID = '1') then
                wnext <= wrresp;
            else
                wnext <= wrdata;
            end if;
        when wrresp =>
            if (BREADY = '1' and BVALID_t = '1') then
                wnext <= wridle;
            else
                wnext <= wrresp;
            end if;
        when others =>
            wnext <= wridle;
        end case;
    end process;

    waddr_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (aw_hs = '1') then
                    waddr <= UNSIGNED(AWADDR(ADDR_BITS-1 downto 2) & (1 downto 0 => '0'));
                end if;
            end if;
        end if;
    end process;

-- ----------------------- AXI READ ----------------------
    ARREADY_t <= '1' when (rstate = rdidle) else '0';
    ARREADY <= ARREADY_t;
    RDATA   <= STD_LOGIC_VECTOR(rdata_data);
    RRESP   <= "00";  -- OKAY
    RVALID_t  <= '1' when (rstate = rddata) else '0';
    RVALID    <= RVALID_t;
    ar_hs   <= ARVALID and ARREADY_t;
    raddr   <= UNSIGNED(ARADDR(ADDR_BITS-1 downto 0));

    -- read FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                rstate <= rdreset;
            elsif (ACLK_EN = '1') then
                rstate <= rnext;
            end if;
        end if;
    end process;

    process (rstate, ARVALID, RREADY, RVALID_t)
    begin
        case (rstate) is
        when rdidle =>
            if (ARVALID = '1') then
                rnext <= rddata;
            else
                rnext <= rdidle;
            end if;
        when rddata =>
            if (RREADY = '1' and RVALID_t = '1') then
                rnext <= rdidle;
            else
                rnext <= rddata;
            end if;
        when others =>
            rnext <= rdidle;
        end case;
    end process;

    rdata_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (ar_hs = '1') then
                    rdata_data <= (others => '0');
                    case (TO_INTEGER(raddr)) is
                    when ADDR_AP_CTRL =>
                        rdata_data(9) <= int_interrupt;
                        rdata_data(7) <= int_auto_restart;
                        rdata_data(3) <= int_ap_ready;
                        rdata_data(2) <= int_ap_idle;
                        rdata_data(1) <= int_task_ap_done;
                        rdata_data(0) <= int_ap_start;
                    when ADDR_GIE =>
                        rdata_data(0) <= int_gie;
                    when ADDR_IER =>
                        rdata_data(1 downto 0) <= int_ier;
                    when ADDR_ISR =>
                        rdata_data(1 downto 0) <= int_isr;
                    when ADDR_AP_RETURN_0 =>
                        rdata_data <= RESIZE(int_ap_return(31 downto 0), 32);
                    when ADDR_MEM_DATA_0 =>
                        rdata_data <= RESIZE(int_mem(31 downto 0), 32);
                    when ADDR_MEM_DATA_1 =>
                        rdata_data <= RESIZE(int_mem(63 downto 32), 32);
                    when ADDR_OPCODE_DATA_0 =>
                        rdata_data <= RESIZE(int_opcode(31 downto 0), 32);
                    when ADDR_SRC_DATA_0 =>
                        rdata_data <= RESIZE(int_src(31 downto 0), 32);
                    when ADDR_DST_DATA_0 =>
                        rdata_data <= RESIZE(int_dst(31 downto 0), 32);
                    when ADDR_WEIGHTS_DATA_0 =>
                        rdata_data <= RESIZE(int_weights(31 downto 0), 32);
                    when ADDR_BIASES_DATA_0 =>
                        rdata_data <= RESIZE(int_biases(31 downto 0), 32);
                    when ADDR_MULTIPLIERS_DATA_0 =>
                        rdata_data <= RESIZE(int_multipliers(31 downto 0), 32);
                    when ADDR_IH_DATA_0 =>
                        rdata_data <= RESIZE(int_ih(31 downto 0), 32);
                    when ADDR_IW_DATA_0 =>
                        rdata_data <= RESIZE(int_iw(31 downto 0), 32);
                    when ADDR_CIN_DATA_0 =>
                        rdata_data <= RESIZE(int_cin(31 downto 0), 32);
                    when ADDR_COUT_DATA_0 =>
                        rdata_data <= RESIZE(int_cout(31 downto 0), 32);
                    when ADDR_KERNEL_DATA_0 =>
                        rdata_data <= RESIZE(int_kernel(31 downto 0), 32);
                    when ADDR_STRIDE_DATA_0 =>
                        rdata_data <= RESIZE(int_stride(31 downto 0), 32);
                    when ADDR_PAD_DATA_0 =>
                        rdata_data <= RESIZE(int_pad(31 downto 0), 32);
                    when ADDR_RELU_DATA_0 =>
                        rdata_data <= RESIZE(int_relu(31 downto 0), 32);
                    when ADDR_POOL_DATA_0 =>
                        rdata_data <= RESIZE(int_pool(31 downto 0), 32);
                    when ADDR_OH_DATA_0 =>
                        rdata_data <= RESIZE(int_oh(31 downto 0), 32);
                    when ADDR_OW_DATA_0 =>
                        rdata_data <= RESIZE(int_ow(31 downto 0), 32);
                    when ADDR_COORDINATES_DATA_0 =>
                        rdata_data <= RESIZE(int_coordinates(31 downto 0), 32);
                    when others =>
                        NULL;
                    end case;
                end if;
            end if;
        end if;
    end process;

-- ----------------------- Register logic ----------------
    interrupt            <= int_interrupt;
    ap_start             <= int_ap_start;
    task_ap_done         <= (ap_done and not auto_restart_status) or auto_restart_done;
    task_ap_ready        <= ap_ready and not int_auto_restart;
    auto_restart_done    <= auto_restart_status and (ap_idle and not int_ap_idle);
    mem                  <= STD_LOGIC_VECTOR(int_mem);
    opcode               <= STD_LOGIC_VECTOR(int_opcode);
    src                  <= STD_LOGIC_VECTOR(int_src);
    dst                  <= STD_LOGIC_VECTOR(int_dst);
    weights              <= STD_LOGIC_VECTOR(int_weights);
    biases               <= STD_LOGIC_VECTOR(int_biases);
    multipliers          <= STD_LOGIC_VECTOR(int_multipliers);
    ih                   <= STD_LOGIC_VECTOR(int_ih);
    iw                   <= STD_LOGIC_VECTOR(int_iw);
    cin                  <= STD_LOGIC_VECTOR(int_cin);
    cout                 <= STD_LOGIC_VECTOR(int_cout);
    kernel               <= STD_LOGIC_VECTOR(int_kernel);
    stride               <= STD_LOGIC_VECTOR(int_stride);
    pad                  <= STD_LOGIC_VECTOR(int_pad);
    relu                 <= STD_LOGIC_VECTOR(int_relu);
    pool                 <= STD_LOGIC_VECTOR(int_pool);
    oh                   <= STD_LOGIC_VECTOR(int_oh);
    ow                   <= STD_LOGIC_VECTOR(int_ow);
    coordinates          <= STD_LOGIC_VECTOR(int_coordinates);

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_interrupt <= '0';
            elsif (ACLK_EN = '1') then
                if (int_gie = '1' and (int_isr(0) or int_isr(1)) = '1') then
                    int_interrupt <= '1';
                else
                    int_interrupt <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_start <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1' and WDATA(0) = '1') then
                    int_ap_start <= '1';
                elsif (ap_ready = '1') then
                    int_ap_start <= int_auto_restart; -- clear on handshake/auto restart
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_done <= ap_done;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_task_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_done = '1') then
                    int_task_ap_done <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_task_ap_done <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_idle <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_idle <= ap_idle;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_ready <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_ready = '1') then
                    int_ap_ready <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_ap_ready <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_auto_restart <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1') then
                    int_auto_restart <= WDATA(7);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                auto_restart_status <= '0';
            elsif (ACLK_EN = '1') then
                if (int_auto_restart = '1') then
                    auto_restart_status <= '1';
                elsif (ap_idle = '1') then
                    auto_restart_status <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_gie <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_GIE and WSTRB(0) = '1') then
                    int_gie <= WDATA(0);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ier <= (others=>'0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IER and WSTRB(0) = '1') then
                    int_ier <= UNSIGNED(WDATA(1 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(0) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(0) = '1' and ap_done = '1') then
                    int_isr(0) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(0) <= int_isr(0) xor WDATA(0); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(1) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(1) = '1' and ap_ready = '1') then
                    int_isr(1) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(1) <= int_isr(1) xor WDATA(1); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_return <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (ap_done = '1') then
                    int_ap_return <= UNSIGNED(ap_return);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_mem(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_MEM_DATA_0) then
                    int_mem(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_mem(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_mem(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_MEM_DATA_1) then
                    int_mem(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_mem(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_opcode(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_OPCODE_DATA_0) then
                    int_opcode(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_opcode(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_src(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SRC_DATA_0) then
                    int_src(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_src(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_dst(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_DST_DATA_0) then
                    int_dst(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_dst(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_weights(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_WEIGHTS_DATA_0) then
                    int_weights(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_weights(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_biases(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BIASES_DATA_0) then
                    int_biases(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_biases(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_multipliers(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_MULTIPLIERS_DATA_0) then
                    int_multipliers(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_multipliers(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ih(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IH_DATA_0) then
                    int_ih(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_ih(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_iw(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IW_DATA_0) then
                    int_iw(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_iw(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_cin(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_CIN_DATA_0) then
                    int_cin(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_cin(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_cout(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_COUT_DATA_0) then
                    int_cout(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_cout(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_kernel(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_KERNEL_DATA_0) then
                    int_kernel(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_kernel(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_stride(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_STRIDE_DATA_0) then
                    int_stride(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_stride(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_pad(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PAD_DATA_0) then
                    int_pad(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_pad(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_relu(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_RELU_DATA_0) then
                    int_relu(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_relu(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_pool(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_POOL_DATA_0) then
                    int_pool(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_pool(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_oh(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_OH_DATA_0) then
                    int_oh(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_oh(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ow(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_OW_DATA_0) then
                    int_ow(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_ow(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_coordinates(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_COORDINATES_DATA_0) then
                    int_coordinates(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_coordinates(31 downto 0));
                end if;
            end if;
        end if;
    end process;


-- ----------------------- Memory logic ------------------

end architecture behave;
