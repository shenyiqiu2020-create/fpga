// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of ap_return
//        bit 31~0 - ap_return[31:0] (Read)
// 0x18 : Data signal of mem
//        bit 31~0 - mem[31:0] (Read/Write)
// 0x1c : Data signal of mem
//        bit 31~0 - mem[63:32] (Read/Write)
// 0x20 : reserved
// 0x28 : Data signal of opcode
//        bit 31~0 - opcode[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of src
//        bit 31~0 - src[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of dst
//        bit 31~0 - dst[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of weights
//        bit 31~0 - weights[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of biases
//        bit 31~0 - biases[31:0] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of multipliers
//        bit 31~0 - multipliers[31:0] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of ih
//        bit 31~0 - ih[31:0] (Read/Write)
// 0x5c : reserved
// 0x60 : Data signal of iw
//        bit 31~0 - iw[31:0] (Read/Write)
// 0x64 : reserved
// 0x68 : Data signal of cin
//        bit 31~0 - cin[31:0] (Read/Write)
// 0x6c : reserved
// 0x70 : Data signal of cout
//        bit 31~0 - cout[31:0] (Read/Write)
// 0x74 : reserved
// 0x78 : Data signal of kernel
//        bit 31~0 - kernel[31:0] (Read/Write)
// 0x7c : reserved
// 0x80 : Data signal of stride
//        bit 31~0 - stride[31:0] (Read/Write)
// 0x84 : reserved
// 0x88 : Data signal of pad
//        bit 31~0 - pad[31:0] (Read/Write)
// 0x8c : reserved
// 0x90 : Data signal of relu
//        bit 31~0 - relu[31:0] (Read/Write)
// 0x94 : reserved
// 0x98 : Data signal of pool
//        bit 31~0 - pool[31:0] (Read/Write)
// 0x9c : reserved
// 0xa0 : Data signal of oh
//        bit 31~0 - oh[31:0] (Read/Write)
// 0xa4 : reserved
// 0xa8 : Data signal of ow
//        bit 31~0 - ow[31:0] (Read/Write)
// 0xac : reserved
// 0xb0 : Data signal of coordinates
//        bit 31~0 - coordinates[31:0] (Read/Write)
// 0xb4 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_AP_CTRL          0x00
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_GIE              0x04
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_IER              0x08
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_ISR              0x0c
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_AP_RETURN        0x10
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_AP_RETURN        32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_MEM_DATA         0x18
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_MEM_DATA         64
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_OPCODE_DATA      0x28
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_OPCODE_DATA      32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_SRC_DATA         0x30
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_SRC_DATA         32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_DST_DATA         0x38
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_DST_DATA         32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_WEIGHTS_DATA     0x40
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_WEIGHTS_DATA     32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_BIASES_DATA      0x48
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_BIASES_DATA      32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_MULTIPLIERS_DATA 0x50
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_MULTIPLIERS_DATA 32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_IH_DATA          0x58
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_IH_DATA          32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_IW_DATA          0x60
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_IW_DATA          32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_CIN_DATA         0x68
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_CIN_DATA         32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_COUT_DATA        0x70
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_COUT_DATA        32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_KERNEL_DATA      0x78
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_KERNEL_DATA      32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_STRIDE_DATA      0x80
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_STRIDE_DATA      32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_PAD_DATA         0x88
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_PAD_DATA         32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_RELU_DATA        0x90
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_RELU_DATA        32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_POOL_DATA        0x98
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_POOL_DATA        32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_OH_DATA          0xa0
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_OH_DATA          32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_OW_DATA          0xa8
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_OW_DATA          32
#define XEFFICIENTAD_ENGINE_CONTROL_ADDR_COORDINATES_DATA 0xb0
#define XEFFICIENTAD_ENGINE_CONTROL_BITS_COORDINATES_DATA 32

